<?php 
session_start();

 ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<!-- login page  register field  1. name email pass isadmin -->

<!-- Bootstrap 5 Contact Form Snippet -->

<div class="container px-5 my-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card border-0 rounded-3 shadow-lg">
        <div class="card-body p-4">
          <div class="text-center">
            <div class="h1 fw-light">Login Form</div>
          </div>

          <!-- * * * * * * * * * * * * * *
          // * * SB Forms Contact Form * *
          // * * * * * * * * * * * * * * *

          // This form is pre-integrated with SB Forms.
          // To make this form functional, sign up at
          // https://startbootstrap.com/solution/contact-forms
          // to get an API token!
          -->

          <form method="post">

         

            <!-- Email Input -->
            <div class="form-floating mb-3">
              <input class="form-control" name="email" id="emailAddress" type="email" placeholder="Email Address" required />
              <label for="emailAddress">Email Address</label>
             
            </div>

               <!-- Password Input -->
               <div class="form-floating mb-3">
              <input class="form-control" name="pass" id="pass" type="password" placeholder="Password" required />
              <label for="pass">Password</label>
              
            </div>
              <!-- ADmin Student Input -->
              
              <select class="form-select my-4" name="role" aria-label="Default select example">
  <option>Select Your Role</option>
  <option value="0">Student</option>
  <option value="1">Admin- (Examiner)</option>

</select>


            <!-- Submit button -->
            <div class="d-grid">
              <button class="btn btn-primary" name="submit"  type="submit">Submit</button>
            </div>
          </form>
          <!-- End of contact form -->

        </div>
      </div>
    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>



<?php 
// connect file 

include 'conn.php';


if($_SERVER['REQUEST_METHOD'] === 'POST'){
  if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $roll = $_POST['role'];

    // check email is exits or not and roll what is 

    if($roll == 0){
        $check_email = "SELECT * FROM `ragister` WHERE email ='$email' And Isadmin = '$roll'";

    $check_email_run = mysqli_query($conn, $check_email);

    $num = mysqli_num_rows($check_email_run);

    if($num>0){
      $get_detail = mysqli_fetch_array($check_email_run);
      if($get_detail['pass'] == $pass){
        $_SESSION['roll'] = $get_detail['Isadmin'];
        header('location:Student.php');
      }else{
        echo  "<p class='text-danger'>Please Field Right Details !</p>";
      }


    }else{
      echo  "<p class='text-danger'>Please Field Right Details !</p>";
    }


    }else{


    $check_email = "SELECT * FROM `ragister` WHERE email ='$email' And Isadmin='$roll'";

    $check_email_run = mysqli_query($conn, $check_email);

    $num = mysqli_num_rows($check_email_run);

    if($num>0){
      $get_detail = mysqli_fetch_array($check_email_run);

      if($get_detail['pass'] == $pass){
        $_SESSION['roll'] = $get_detail['Isadmin'];
        header('location:Admin.php');

      }else{
        echo  "<p class='text-danger'>Please  Field Right Details !</p>";
      }


    }else{
      echo  "<p class='text-danger'>Please Field Right Details !</p>";
    }


    }

  




  }
}
 ?>


