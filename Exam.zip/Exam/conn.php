<?php 
$server = 'localhost';
$username = 'root';
$pass = '';
$dbname = 'demo';



$conn = mysqli_connect($server, $username, $pass, $dbname);


 ?>