
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="modal-title fs-4 text-warning" id="exampleModalLabel">Exam Upload Form</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" enctype="multipart/form-data">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Exam Name</label>
    <input type="text" name="exam_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
 
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Exam Max. Marks</label>
    <input type="text" name="exam_max_marks" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
      <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Exam Max. Duration</label>
    <input type="text" name="exam_max_dur" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Exam File</label>
    <input type="file" name="exam_file" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="submit" class="btn btn-primary">Add Exam</button>
      </div>
</form>
    </div>
  </div>
</div>


