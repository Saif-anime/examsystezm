<!-- there admin page  exam excel file upload and set the time -->
<?php 
session_start();


if(!isset($_SESSION['roll']) || $_SESSION['roll'] == 0){
	header('location:Login.php');
}

 ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  </head>
  <body>
  	<?php 
include './component/Navbar.php';
include './component/Modal.php';

  	 ?>

  	 <div class="container">
  	 	       <!-- Button trigger modal -->
<button type="button" class="btn btn-warning btn-sm float-end my-4" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Add Exam
</button>


<div class="container-fluid">
	<h3 class="text-center">All Exam List</h3>
	<table class="table border border-1">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Exam Name</th>
      <th scope="col">Exam Code</th>
      <th scope="col">Exam Max. Marks</th>
       <th scope="col">Exam Duration</th>

      <th scope="col" class="text-center">Action</th>
    </tr>
  </thead>
  <tbody>

  	<?php 
  	include "conn.php";

  	$select = "SELECT * FROM `exam_upload`";
  	$select_run = mysqli_query($conn, $select);
  	$num = mysqli_num_rows($select_run);
  	if($num>0){
  		while($fetch_exam = mysqli_fetch_array($select_run)){
  			?><tr>
      <th scope='row'><?php echo $fetch_exam['id'];?></th>
      <td><?php echo $fetch_exam['exam_name'];?></td>
     <td><?php echo $fetch_exam['exam_code'];?></td>
        <td><?php echo $fetch_exam['exam_marks'];?></td>
           <td><?php echo $fetch_exam['exam_duration'];?> Min.</td>
       
      <td class='d-flex justify-content-center'>
      	<a type='button' class='btn btn-danger btn-sm me-4'>Delete</a>
      	  <a type='button' class='btn btn-success btn-sm ms-4'>Update</a>
      </td>	

    </tr>;

    <?php
  		}
  	}else{
  		echo "<p class='text-dark'>Sorry Data Not Found !</p>";
  	}


  	 ?>
  
  
  </tbody>
</table>
</div>



  	 </div>
  
  </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</html>


<?php 

include './conn.php';

$exam_code = 101;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  if(isset($_POST['submit'])){
    // form data get 
    $exam_code+=1;
    $exam_name = $_POST['exam_name'];
    $exam_marks = $_POST['exam_max_marks'];
    $exam_file = $_FILES['exam_file'];
    $exam_duration = $_POST['exam_max_dur'];

    // file uploader 
    $exam_file_name = $exam_file['name'];
    $exam_folder = "Exam_File/".$exam_file_name;
    $exam_file_tmp_name = $exam_file['tmp_name'];
    $exam_file_error = $exam_file['error'];
    $exam_file_type = $exam_file['type'];

    $exam_table_name = $exam_name."$exam_code";
    if($exam_file_error == 0){

      // file uploaded here 
      $exam_file_upload = move_uploaded_file($exam_file_tmp_name, $exam_folder);

      // exam table file 
      if($exam_file_upload){
        // insert exam table 
$update_time = date("Y/m/d");
$insert_query = "INSERT INTO `exam_upload`(`exam_name`, `exam_code`, `exam_marks`, `exam_file`,`update_time`, `exam_duration`) VALUES ('$exam_name','$exam_code','$exam_marks','$exam_folder','$update_time','$exam_duration')";

$insert_query_run = mysqli_query($conn, $insert_query);

if($insert_query_run){

	echo "<script> alert('Exam Uploaded Successfully !')</script>";

        // there table created 
$table_create = "CREATE TABLE $exam_table_name (
    id int NOT NULL AUTO_INCREMENT,
    Question text(1000) NOT NULL,
    A varchar(255) NOT Null,
    B varchar(255) NOT Null,
    C varchar(255) NOT Null,
    D varchar(255) NOT Null,
    Ans varchar(255) NOT Null,
    `created_at` datetime NOT NULL,
    `updated_at` datetime NOT NULL,
    PRIMARY KEY (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
$exam_table_run = mysqli_query($conn, $table_create);

// file insert this table

    // Open uploaded CSV file with read-only mode
        $csvFile = fopen($exam_folder, 'r');

         // Skip the first line
        fgetcsv($csvFile);


  // Parse data from CSV file line by line        
        while (($getData = fgetcsv($csvFile, 10000, ",")) !== FALSE)
        {
            // Get row data
            $question = $getData[0];
            $a = $getData[1];     
            $b = $getData[2];       
            $c = $getData[3];
            $d = $getData[4];
            $ans = $getData[5];

            $file_insert = "INSERT INTO `$exam_table_name` (`Question`, `A`,`B`,`C`,`D`,`Ans`, `created_at`,`updated_at`) VALUES ('$question','$a','$b','$c','$d','$ans','NOW()', 'NOW()')";
                mysqli_query($conn, $file_insert);
            
        }

        // Close opened CSV file
        fclose($csvFile);
}else{
  echo "<p class='text-danger'>Exam Uploaded Not Successfully !</p>";
}
        
}else{
        echo "<p class='text-danger'> Exam file Error please upload another file !</p>";
      }

}else{
      echo "<p class='text-danger'> Exam file Error please upload another file !</p>";
    }


  }
}



 ?>