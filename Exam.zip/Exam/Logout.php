<!-- there is logout page  -->
<?php 
session_start();

unset($_SESSION['roll']);

header("location:Login.php");


 ?>